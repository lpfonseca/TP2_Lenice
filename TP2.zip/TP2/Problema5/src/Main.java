import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws IOException {

        ArrayList<Double> sales = new ArrayList<>();
        ArrayList<String> client = new ArrayList<>();

        BufferedReader readCli = new BufferedReader(new FileReader("/home/lenice/Documentos/UTA/POO/Problema5/src/clientes.txt"));
        BufferedReader readComp = new BufferedReader(new FileReader("/home/lenice/Documentos/UTA/POO/Problema5/src/compra.txt"));

        String linha = " ";
        while (true) {
            if (linha != null) {
                System.out.println(linha);
                linha = readCli.readLine();
                client.add(linha);
            }
            else {
                break;
            }

        }

        double linha1 = 0;
        while (true) {
            if (linha1 != -1) {
                System.out.println(linha1);
                linha1 = readComp.read();
                sales.add(linha1);
                //sales.add(Double.valueOf(linha1));
            }
            else {
                break;
            }

        }

        System.out.println(client);
        System.out.println(sales);

        System.out.println(nameOfBestCustomer(sales, client));

        readComp.close();
        readCli.close();
    }

    static String nameOfBestCustomer(ArrayList<Double> sales, ArrayList<String> customers) throws IOException {

        Double maior = 0.0;
        for (int i = 0; i < sales.size(); i++) {
            if (sales.get(i) > maior) {
                maior = sales.get(i);
            }
        }

        int indice = sales.indexOf(maior);

        String nome = " ";
        for (int j = 0; j < customers.size(); j++) {
            nome = customers.get(indice);
        }

        return nome;
    }
}